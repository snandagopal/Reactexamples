import "./styles.css";
import React, { Component } from "react";
import Professor from "./Comp/Professor";
import Student from "./Comp/Student";
import College from "./Comp/College";
//import CollegeDetails from "./Comp/College";

export default function App() {
  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
      <Professor />
      <Student />
      <College />

      <h2>Start editing to see some magic happen!</h2>
    </div>
  );
}
