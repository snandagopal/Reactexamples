import React, {Component} from 'react';

class Student extends Component{
  render(){
    return(
          <li> This is Student's  page</li>

    )
  }

}
export default Student;