import React, { Component } from "react";

class College extends Component {
  render() {
    return (
      <li>
        {" "}
        <i>This College Details</i>
      </li>
    );
  }
}
export default College;
