import React, {Component} from 'react';

class Professor extends Component{
  render(){
    return(
          <li> This is Professors page</li>

    )
  }

}
export default Professor;